package unthinkable.code.review.Assistant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeReviewAssistantApplicationTests {

	@Test
	void contextLoads() {
	}

}
